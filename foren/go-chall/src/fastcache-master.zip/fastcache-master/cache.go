// Package fastcache provides high-performance in-memory caching with LRU and expirable cache implementations.
//
// This file defines the public interfaces and constructors for the fastcache module.
// It provides the Cache and ExpirableCache interfaces, and constructors for LRU and expirable caches.
package fastcache

import "time"

// Cache is a thread-safe in-memory cache interface.
type Cache interface {
	Set(key string, value interface{})
	Get(key string) (*Item, bool)
	Delete(key string)
	Purge()
	Len() int
}

// ExpirableCache is a thread-safe in-memory cache with TTL support.
type ExpirableCache interface {
	Add(key string, value interface{}, ttl time.Duration)
	Get(key string) (*Item, bool)
	Delete(key string)
	Purge()
	Len() int
}

// NewLRU creates a new LRU cache with the given size.
func NewLRU(size int) Cache {
	return newLRUCache(size)
}

// NewExpirable creates a new expirable cache with the given size.
func NewExpirable(size int) ExpirableCache {
	return newExpirableCache(size)
}
