// Package fastcache provides high-performance in-memory caching with LRU and expirable cache implementations.
//
// This file defines the public interfaces and constructors for the fastcache module.
// It provides the Cache and ExpirableCache interfaces, and constructors for LRU and expirable caches.
package fastcache

import "time"

// Stats holds cache statistics.
type Stats struct {
	Hits      int64 // Number of cache hits
	Misses    int64 // Number of cache misses
	Evictions int64 // Number of evicted items
}

// Cache is a thread-safe in-memory cache interface.
type Cache interface {
	Set(key string, value interface{})
	Get(key string) (*Item, bool)
	Delete(key string)
	Purge()
	Len() int
	Peek(key string) (*Item, bool) // Lookup without affecting LRU order
	Stats() Stats                  // Returns cache statistics
}

// ExpirableCache is a thread-safe in-memory cache with TTL support.
type ExpirableCache interface {
	Add(key string, value interface{}, ttl time.Duration)
	Get(key string) (*Item, bool)
	Delete(key string)
	Purge()
	Len() int
	Peek(key string) (*Item, bool) // Lookup without affecting LRU order
	ClearExpired() int             // Removes expired items, returns number removed
	Stats() Stats                  // Returns cache statistics
}

// NewLRU creates a new LRU cache with the given size.
func NewLRU(size int) Cache {
	return newLRUCache(size)
}

// NewExpirable creates a new expirable cache with the given size.
func NewExpirable(size int) ExpirableCache {
	return newExpirableCache(size)
}
