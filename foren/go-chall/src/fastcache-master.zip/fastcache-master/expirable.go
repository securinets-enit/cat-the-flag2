// expirable.go
// This file implements an expirable cache with TTL (Time-To-Live) support for the fastcache module.
// It provides a map-based cache with optional janitor goroutine for cleanup.
// expirable.go implements a thread-safe expirable cache with TTL support.
package fastcache

import (
	"sync"
	"time"
)

type expirableCache struct {
	mu          sync.RWMutex
	cap         int
	items       map[string]*expirableItem
	janitorStop chan struct{}
}

type expirableItem struct {
	item      *Item
	expiresAt time.Time
}

func newExpirableCache(size int) ExpirableCache {
	if size <= 0 {
		size = 128
	}
	c := &expirableCache{
		cap:         size,
		items:       make(map[string]*expirableItem),
		janitorStop: make(chan struct{}),
	}
	go c.janitor()
	return c
}

func (c *expirableCache) Add(key string, value interface{}, ttl time.Duration) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if len(c.items) >= c.cap {
		c.evictOne()
	}
	et := time.Now().Add(ttl)
	c.items[key] = &expirableItem{
		item:      &Item{value: value},
		expiresAt: et,
	}
}

func (c *expirableCache) Get(key string) (*Item, bool) {
	c.mu.RLock()
	item, ok := c.items[key]
	c.mu.RUnlock()
	if !ok {
		return nil, false
	}
	if time.Now().After(item.expiresAt) {
		c.mu.Lock()
		delete(c.items, key)
		c.mu.Unlock()
		return nil, false
	}
	return item.item, true
}

func (c *expirableCache) Delete(key string) {
	c.mu.Lock()
	defer c.mu.Unlock()
	delete(c.items, key)
}

func (c *expirableCache) Purge() {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.items = make(map[string]*expirableItem)
}

func (c *expirableCache) Len() int {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return len(c.items)
}

func (c *expirableCache) evictOne() {
	for k := range c.items {
		delete(c.items, k)
		return
	}
}

func (c *expirableCache) janitor() {
	ticker := time.NewTicker(1 * time.Minute)
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			c.cleanup()
		case <-c.janitorStop:
			return
		}
	}
}

func (c *expirableCache) cleanup() {
	now := time.Now()
	c.mu.Lock()
	for k, v := range c.items {
		if now.After(v.expiresAt) {
			delete(c.items, k)
		}
	}
	c.mu.Unlock()
}
