// lru.go
// This file implements a thread-safe LRU (Least Recently Used) cache for the fastcache module.
// It uses container/list for efficient LRU management.

package fastcache

import (
	"container/list"
	"sync"
)

// lruCache is the structure that holds the LRU cache data.
type lruCache struct {
	mu    sync.Mutex
	cap   int
	ll    *list.List
	cache map[string]*list.Element
	stats Stats // Tracks cache statistics
}

// entry is the structure that represents a single entry in the cache.
type entry struct {
	key  string
	item *Item
}

// newLRUCache initializes and returns a new LRU cache instance.
func newLRUCache(size int) Cache {
	if size <= 0 {
		size = 128
	}
	return &lruCache{
		cap:   size,
		ll:    list.New(),
		cache: make(map[string]*list.Element),
	}
}

// Set adds a new key-value pair to the cache or updates the value of an existing key.
func (c *lruCache) Set(key string, value interface{}) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if ee, ok := c.cache[key]; ok {
		c.ll.MoveToFront(ee)
		ee.Value.(*entry).item.value = value
		return
	}
	it := &Item{value: value}
	e := c.ll.PushFront(&entry{key, it})
	c.cache[key] = e
	if c.ll.Len() > c.cap {
		c.removeOldest()
	}
}

// Get retrieves the value associated with the given key from the cache and updates stats.
func (c *lruCache) Get(key string) (*Item, bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if ee, ok := c.cache[key]; ok {
		c.ll.MoveToFront(ee)
		c.stats.Hits++
		return ee.Value.(*entry).item, true
	}
	c.stats.Misses++
	return nil, false
}

// Peek returns the value for the given key without updating LRU order or stats.
func (c *lruCache) Peek(key string) (*Item, bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if ee, ok := c.cache[key]; ok {
		return ee.Value.(*entry).item, true
	}
	return nil, false
}

// Stats returns a copy of the cache statistics.
func (c *lruCache) Stats() Stats {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.stats
}

// Delete removes the key-value pair associated with the given key from the cache.
func (c *lruCache) Delete(key string) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if ee, ok := c.cache[key]; ok {
		c.removeElement(ee)
	}
}

// Purge clears the cache, removing all key-value pairs.
func (c *lruCache) Purge() {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.ll.Init()
	c.cache = make(map[string]*list.Element)
}

// Len returns the number of items currently in the cache.
func (c *lruCache) Len() int {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.ll.Len()
}

// removeOldest removes the least recently used item from the cache.
func (c *lruCache) removeOldest() {
	e := c.ll.Back()
	if e != nil {
		c.stats.Evictions++
		c.removeElement(e)
	}
}

// removeElement is a helper function that removes an element from the cache.
func (c *lruCache) removeElement(e *list.Element) {
	c.ll.Remove(e)
	kv := e.Value.(*entry)
	delete(c.cache, kv.key)
}
