// item.go
// This file defines the Item struct and its Value() method for the fastcache module.
// Item wraps a cached value and provides access to it.

package fastcache

// Item represents a value stored in the cache.
type Item struct {
	value interface{}
}

// Value returns the value stored in the Item.
func (i *Item) Value() interface{} {
	return i.value
}
