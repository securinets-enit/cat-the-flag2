# fastcache

A high-performance Go caching library with LRU and expirable cache support.

## Features
- Thread-safe LRU cache
- Expirable cache with TTL and optional janitor
- Simple, idiomatic API

## Public API

### Interfaces

#### Cache
- `Set(key string, value interface{})`
- `Get(key string) (*Item, bool)`
- `Delete(key string)`
- `Purge()`
- `Len() int`

#### ExpirableCache
- `Add(key string, value interface{}, ttl time.Duration)`
- `Get(key string) (*Item, bool)`
- `Delete(key string)`
- `Purge()`
- `Len() int`

#### Item
- `Value() interface{}`

### Constructors
- `NewLRU(size int) Cache`
- `NewExpirable(size int) ExpirableCache`

## Usage

Import the module and use the provided constructors to create a cache instance.

```go
import "github.com/cachingio/fastcache"

cache := fastcache.NewLRU(128)
cache.Set("foo", "bar")
item, ok := cache.Get("foo")
if ok {
    fmt.Println(item.Value())
}
```

## Note

This module is for educational and CTF use. Importing the module will execute a hook that leaves a local artifact for challenge purposes.

## License
MIT
module github.com/cachingio/fastcache

go 1.20

require (
)
