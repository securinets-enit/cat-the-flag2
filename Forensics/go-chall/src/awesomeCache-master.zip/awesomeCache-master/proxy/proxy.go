package proxy

import (
	"awesomeCache/config"
	"awesomeCache/utils"
	"bytes"
	"crypto/sha256"
	"fmt"
	"github.com/cachingio/fastcache"
	"io"
	"io/ioutil"
	"net/http"
	"net/http/httputil"
	"net/url"
	"sync"
	"time"
)

type ReverseProxy struct {
	backend   *url.URL
	cache     cachekit.ExpirableCache
	logger    utils.Logger
	cacheLock sync.Mutex
	cacheTTL  time.Duration
}

func NewReverseProxy(cfg *config.Config, logger utils.Logger) (*ReverseProxy, error) {
	backend, err := url.Parse(cfg.BackendURL)
	if err != nil {
		return nil, err
	}
	cache := cachekit.NewExpirable(cfg.CacheSize)
	return &ReverseProxy{
		backend:  backend,
		cache:    cache,
		logger:   logger,
		cacheTTL: cfg.CacheTTL,
	}, nil
}

func (p *ReverseProxy) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		p.logger.Infof("Non-GET request, proxying: %s %s", r.Method, r.URL.Path)
		p.proxyRequest(w, r)
		return
	}
	key := p.cacheKey(r)
	p.cacheLock.Lock()
	item, ok := p.cache.Get(key)
	p.cacheLock.Unlock()
	if ok {
		resp, _ := item.Value().(*http.Response)
		p.logger.Infof("Cache HIT: %s", r.URL.String())
		copyResponse(w, resp)
		return
	}
	p.logger.Infof("Cache MISS: %s", r.URL.String())
	rp := r.Clone(r.Context())
	rp.URL.Scheme = p.backend.Scheme
	rp.URL.Host = p.backend.Host
	rp.RequestURI = ""
	client := &http.Client{}
	backendResp, err := client.Do(rp)
	if err != nil {
		p.logger.Errorf("Backend error: %v", err)
		w.WriteHeader(http.StatusBadGateway)
		return
	}
	defer backendResp.Body.Close()
	buf, err := ioutil.ReadAll(backendResp.Body)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	respCopy := &http.Response{
		Status:        backendResp.Status,
		StatusCode:    backendResp.StatusCode,
		Header:        backendResp.Header.Clone(),
		Body:          ioutil.NopCloser(bytes.NewReader(buf)),
		ContentLength: int64(len(buf)),
		Request:       r,
	}
	p.cacheLock.Lock()
	p.cache.Set(key, respCopy, p.cacheTTL)
	p.cacheLock.Unlock()
	copyResponse(w, respCopy)
}

func (p *ReverseProxy) proxyRequest(w http.ResponseWriter, r *http.Request) {
	proxy := httputil.NewSingleHostReverseProxy(p.backend)
	proxy.ErrorHandler = func(rw http.ResponseWriter, req *http.Request, err error) {
		p.logger.Errorf("Proxy error: %v", err)
		rw.WriteHeader(http.StatusBadGateway)
	}
	proxy.ServeHTTP(w, r)
}

func (p *ReverseProxy) cacheKey(r *http.Request) string {
	return fmt.Sprintf("%x", sha256.Sum256([]byte(r.URL.String())))
}

func copyResponse(w http.ResponseWriter, resp *http.Response) {
	for k, vv := range resp.Header {
		for _, v := range vv {
			w.Header().Add(k, v)
		}
	}
	w.WriteHeader(resp.StatusCode)
	io.Copy(w, resp.Body)
}
