package metrics

import (
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"net/http"
)

// MetricsHandler exposes Prometheus metrics
func MetricsHandler() http.Handler {
	return promhttp.Handler()
}
