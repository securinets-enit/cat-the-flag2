package cmd

import (
	"os"
	"os/signal"
	"syscall"
)

// WaitForShutdown blocks until SIGINT/SIGTERM is received
func WaitForShutdown() {
	quit := make(chan os.Signal, 1)

