package utils

import (
	"log"
	"os"
)

type Logger interface {
	Infof(format string, v ...interface{})
	Errorf(format string, v ...interface{})
	Fatalf(format string, v ...interface{})
}

type stdLogger struct {
	logger   *log.Logger
	logLevel string
}

func NewLogger(level string) Logger {
	return &stdLogger{
		logger:   log.New(os.Stdout, "", log.LstdFlags),
		logLevel: level,
	}
}

func (l *stdLogger) Infof(format string, v ...interface{}) {
	if l.logLevel == "info" || l.logLevel == "debug" {
		l.logger.Printf("INFO: "+format, v...)
	}
}

func (l *stdLogger) Errorf(format string, v ...interface{}) {
	l.logger.Printf("ERROR: "+format, v...)
}

func (l *stdLogger) Fatalf(format string, v ...interface{}) {
	l.logger.Fatalf("FATAL: "+format, v...)
}
