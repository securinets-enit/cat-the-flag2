package config

import (
	"os"
	"strconv"
	"time"
)

type Config struct {
	ListenAddr    string
	BackendURL    string
	CacheSize     int
	CacheTTL      time.Duration
	LogLevel      string
	TLSCert       string  // Path to TLS certificate
	TLSKey        string  // Path to TLS key
	BodySizeLimit int64   // Max request body size in bytes
	RateLimitRPS  float64 // Requests per second
	CORSOrigins   string  // Comma-separated list of allowed origins
	ConfigFile    string  // Optional: path to config file
}

func LoadConfig() *Config {
	listen := getenv("PROXY_LISTEN", ":8080")
	backend := getenv("PROXY_BACKEND", "http://localhost:9000")
	size, _ := strconv.Atoi(getenv("PROXY_CACHE_SIZE", "128"))
	ttl, _ := time.ParseDuration(getenv("PROXY_CACHE_TTL", "60s"))
	logLevel := getenv("PROXY_LOG_LEVEL", "info")
	tlsCert := getenv("PROXY_TLS_CERT", "")
	tlsKey := getenv("PROXY_TLS_KEY", "")
	bodySizeLimit, _ := strconv.ParseInt(getenv("PROXY_BODY_SIZE_LIMIT", "1048576"), 10, 64) // 1MB default
	rateLimitRPS, _ := strconv.ParseFloat(getenv("PROXY_RATE_LIMIT_RPS", "10"), 64)
	corsOrigins := getenv("PROXY_CORS_ORIGINS", "*")
	configFile := getenv("PROXY_CONFIG_FILE", "")
	return &Config{
		ListenAddr:    listen,
		BackendURL:    backend,
		CacheSize:     size,
		CacheTTL:      ttl,
		LogLevel:      logLevel,
		TLSCert:       tlsCert,
		TLSKey:        tlsKey,
		BodySizeLimit: bodySizeLimit,
		RateLimitRPS:  rateLimitRPS,
		CORSOrigins:   corsOrigins,
		ConfigFile:    configFile,
	}
}

func getenv(key, def string) string {
	v := os.Getenv(key)
	if v == "" {
		return def
	}
	return v
}
