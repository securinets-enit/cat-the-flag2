package cache_test

import (
	"awesomeCache/cache"
	"testing"
)

func TestCacheInitAndSetGet(t *testing.T) {
	err := cache.Init(2)
	if err != nil {
		t.Fatalf("cache.Init failed: %v", err)
	}
	cache.Cache.Set("foo", "bar")
	item, ok := cache.Cache.Get("foo")
	if !ok || item.Value() != "bar" {
		t.Errorf("expected to get 'bar', got '%v'", item.Value())
	}
}
