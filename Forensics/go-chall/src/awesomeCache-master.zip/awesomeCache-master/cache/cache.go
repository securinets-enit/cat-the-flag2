package cache

import (
	"github.com/cachingio/fastcache"
)

// Cache wraps a fastcache LRU cache
var Cache fastcache.Cache

// Init initializes the fastcache LRU cache
func Init(size int) error {
	Cache = fastcache.NewLRU(size)
	return nil
}
