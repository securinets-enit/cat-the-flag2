package main

import (
	"awesomeCache/cache"
	"awesomeCache/cmd"
	"awesomeCache/config"
	"awesomeCache/health"
	"awesomeCache/metrics"
	"awesomeCache/proxy"
	"awesomeCache/tracing"
	"awesomeCache/utils"
	"context"
	"crypto/tls"
	"fmt"
	"github.com/NYTimes/gziphandler"
	"github.com/gorilla/handlers"
	"github.com/justinas/alice"
	"github.com/natefinch/lumberjack"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"github.com/rs/cors"
	"github.com/sirupsen/logrus"
	"github.com/ulule/limiter/v3"
	limiterMiddleware "github.com/ulule/limiter/v3/drivers/middleware/stdlib"
	limiterMemory "github.com/ulule/limiter/v3/drivers/store/memory"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"syscall"
	"time"
)

func main() {
	cfg := config.LoadConfig()

	// Advanced logger with rotation
	logrus.SetOutput(&lumberjack.Logger{
		Filename:   cfg.LogFile,
		MaxSize:    10, // megabytes
		MaxBackups: 3,
		MaxAge:     28, //days
	})
	logrus.SetLevel(logrus.InfoLevel)

	// Init cache
	if err := cache.Init(1024); err != nil {
		logrus.Fatalf("Failed to initialize cache: %v", err)
	}

	// Init tracing
	tracing.Init("awesomeCache")

	// Set up rate limiter
	store := limiterMemory.NewStore()
	rate := limiter.Rate{Period: time.Second, Limit: int64(cfg.RateLimitRPS)}
	limiterInstance := limiter.New(store, rate)
	limiterMw := limiterMiddleware.NewMiddleware(limiterInstance)

	// Set up CORS
	corsOrigins := strings.Split(cfg.CORSOrigins, ",")
	corsMw := cors.New(cors.Options{
		AllowedOrigins:   corsOrigins,
		AllowCredentials: true,
	})

	// Set up proxy
	p, err := proxy.NewReverseProxy(cfg, logger)
	if err != nil {
		log.Fatalf("Failed to create proxy: %v", err)
	}

	// Set up middleware chain
	chain := alice.New(
		limiterMw.Handler,
		corsMw.Handler,
		gziphandler.GzipHandler,
		handlers.LoggingHandler(os.Stdout, http.DefaultServeMux),
		bodySizeLimitMiddleware(cfg.BodySizeLimit),
	)

	// Register endpoints
	http.Handle("/metrics", metrics.MetricsHandler())
	http.HandleFunc("/healthz", health.HealthHandler)
	http.HandleFunc("/readyz", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("READY"))
	})
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		chain.Then(p).ServeHTTP(w, r)
	})

	srv := &http.Server{
		Addr:         cfg.ListenAddr,
		Handler:      nil, // http.DefaultServeMux
		ReadTimeout:  30 * time.Second,
		WriteTimeout: 30 * time.Second,
		IdleTimeout:  120 * time.Second,
	}

	// TLS support
	go func() {
		var err error
		if cfg.TLSCert != "" && cfg.TLSKey != "" {
			cert, err := tls.LoadX509KeyPair(cfg.TLSCert, cfg.TLSKey)
			if err != nil {
				logger.Fatalf("Failed to load TLS cert: %v", err)
			}
			srv.TLSConfig = &tls.Config{Certificates: []tls.Certificate{cert}}
			logger.Infof("Starting HTTPS reverse caching proxy on %s", cfg.ListenAddr)
			err = srv.ListenAndServeTLS(cfg.TLSCert, cfg.TLSKey)
		} else {
			logger.Infof("Starting HTTP reverse caching proxy on %s", cfg.ListenAddr)
			err = srv.ListenAndServe()
		}
		if err != nil && err != http.ErrServerClosed {
			logger.Fatalf("Server failed: %v", err)
		}
	}()

	// Graceful shutdown
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	logger.Info("Shutting down server...")
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	if err := srv.Shutdown(ctx); err != nil {
		logger.Errorf("HTTP server Shutdown: %v", err)
	}
	logger.Info("Server gracefully stopped")
}

// bodySizeLimitMiddleware limits the size of request bodies
func bodySizeLimitMiddleware(limit int64) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			r.Body = http.MaxBytesReader(w, r.Body, limit)
			next.ServeHTTP(w, r)
		})
	}
}
