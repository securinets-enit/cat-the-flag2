# Reverse Caching Proxy (Proof of Concept)

A simple reverse proxy server with in-memory LRU caching for GET requests.

## Features
- Reverse proxy to a configurable backend
- Caches GET responses in-memory (LRU, TTL)
- Logging of requests and cache hits/misses
- Configurable via environment variables

## Usage

1. Install dependencies:
   ```sh
   go mod tidy
   ```
2. Run the proxy:
   ```sh
   go run main.go
   ```

## Configuration

Set environment variables as needed:
- `PROXY_LISTEN` (default `:8080`)
- `PROXY_BACKEND` (default `http://localhost:9000`)
- `PROXY_CACHE_SIZE` (default `128`)
- `PROXY_CACHE_TTL` (default `60s`)
- `PROXY_LOG_LEVEL` (default `info`)

## Dependencies
- [github.com/hashicorp/golang-lru/v2/expirable](https://github.com/hashicorp/golang-lru)

## Example

Start a backend server (e.g., with Python):
```sh
python3 -m http.server 9000
```

Then run the proxy and access http://localhost:8080
package main

import (
	"awesomeCache/config"
	"awesomeCache/proxy"
	"awesomeCache/utils"
	"log"
	"net/http"
	"os"
)

func main() {
	cfg := config.LoadConfig()
	logger := utils.NewLogger(cfg.LogLevel)
	p, err := proxy.NewReverseProxy(cfg, logger)
	if err != nil {
		log.Fatalf("Failed to create proxy: %v", err)
	}
	logger.Infof("Starting reverse caching proxy on %s, forwarding to %s", cfg.ListenAddr, cfg.BackendURL)
	if err := http.ListenAndServe(cfg.ListenAddr, p); err != nil {
		logger.Fatalf("Server failed: %v", err)
	}
}

