package tracing_test

import (
	"awesomeCache/health"
	"net/http"
	"net/http/httptest"
	"testing"
	"awesomeCache/tracing"
)

func TestInit(t *testing.T) {
	tracing.Init("testService")
	if tracing.Tracer == nil {
		t.Error("tracer should not be nil after Init")
	}
}
package health_test

import (
	"net/http"
	"net/http/httptest"
	"testing"
	"awesomeCache/health"
)

func TestHealthHandler(t *testing.T) {
	req := httptest.NewRequest("GET", "/healthz", nil)
	rr := httptest.NewRecorder()
	health.HealthHandler(rr, req)
	if rr.Code != http.StatusOK {
		t.Errorf("expected 200 OK, got %d", rr.Code)
	}
	if rr.Body.String() != "OK" {
		t.Errorf("expected body 'OK', got '%s'", rr.Body.String())
	}
}

