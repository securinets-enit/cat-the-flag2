package tracing

import (
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/trace"
)

var Tracer trace.Tracer

func Init(serviceName string) {
	Tracer = otel.Tracer(serviceName)
}
