# awesomeCache Project Overview

## Introduction

**awesomeCache** is a high-performance, extensible HTTP reverse proxy with built-in caching, rate limiting, health checks, metrics, and tracing. It is designed to sit in front of a backend service, cache GET requests, and provide observability and operational features out of the box.

---

## Project Structure

```
.
├── cache/         # Caching logic and cache initialization
├── cmd/           # Command-line entry points (e.g., serve, shutdown)
├── config/        # Configuration loading and parsing
├── health/        # Health check endpoints and logic
├── metrics/       # Prometheus metrics integration
├── proxy/         # Reverse proxy and HTTP handler logic
├── tracing/       # Distributed tracing support
├── utils/         # Utility functions (e.g., logging)
├── main.go        # Main entry point
├── go.mod         # Go module definition
├── Dockerfile     # Containerization support
└── README.md      # Project documentation
```

---

## Key Features

- **Reverse Proxy**: Forwards HTTP requests to a backend server.
- **Caching**: Caches GET responses using an in-memory LRU cache (via `github.com/cachingio/fastcache`).
- **Rate Limiting**: Limits the number of requests per client.
- **Health Checks**: Exposes endpoints for liveness/readiness.
- **Metrics**: Exposes Prometheus-compatible metrics.
- **Tracing**: Integrates with distributed tracing systems.
- **Configurable**: Uses a config file or environment variables for setup.

---

## How It Works

### 1. Startup

- The application starts via `main.go`, which loads configuration, initializes logging, cache, metrics, and tracing.
- The HTTP server is started, and the reverse proxy handler is registered.

### 2. Reverse Proxy & Caching

- All incoming HTTP requests are handled by the `ReverseProxy` in `proxy/proxy.go`.
- For **GET** requests:
  - The proxy checks if the response is cached.
  - If cached, it serves the response directly (cache HIT).
  - If not cached, it forwards the request to the backend, caches the response, and serves it (cache MISS).
- For **non-GET** requests:
  - The proxy forwards the request directly to the backend (no caching).

#### Caching Details

- The cache is implemented using `github.com/cachingio/fastcache`.
- The cache key is a SHA256 hash of the request URL.
- Cached responses are serialized and stored as byte slices.
- The cache is thread-safe, using a mutex for concurrent access.

### 3. Rate Limiting

- The project uses `github.com/ulule/limiter/v3` to limit requests per client IP.
- Rate limiting is applied as middleware before requests reach the proxy.

### 4. Health Checks

- Endpoints like `/health` are provided for liveness/readiness checks.
- Implemented in `health/health.go`.

### 5. Metrics

- Prometheus metrics are exposed at `/metrics`.
- Implemented in `metrics/metrics.go`.

### 6. Tracing

- Distributed tracing is supported via the `tracing/` package.
- Integrates with tracing backends (e.g., Jaeger, Zipkin).

---

## Example Request Flow

1. **Client** sends a GET request to the proxy.
2. **Proxy** checks the cache:
   - If HIT: returns cached response.
   - If MISS: forwards to backend, caches the response, returns it to the client.
3. **Metrics** and **tracing** are recorded for each request.
4. **Rate limiting** is enforced per client.

---

## Main Components

### `proxy/proxy.go`

- Core reverse proxy logic.
- Handles caching using fastcache.
- Serializes/deserializes HTTP responses for storage.

### `cache/cache.go`

- Initializes the cache.
- Provides a global cache instance.

### `config/config.go`

- Loads configuration from file or environment.

### `metrics/metrics.go`

- Sets up and exposes Prometheus metrics.

### `health/health.go`

- Implements health check endpoints.

### `utils/logger.go`

- Provides a logger interface and implementation.

---

## How to Run

1. **Build**:  
   ```sh
   go build -o awesomeCache main.go
   ```

2. **Run**:  
   ```sh
   ./awesomeCache --config config.yaml
   ```

3. **Docker**:  
   ```sh
   docker build -t awesomecache .
   docker run -p 8080:8080 awesomecache
   ```

---

## Configuration

- Backend URL, cache size, rate limits, and other settings are configurable via a YAML file or environment variables.
- See `config/config.go` and `README.md` for details.

---

## Extending the Project

- Add new middleware for authentication, logging, etc.
- Swap out the cache backend for a distributed cache if needed.
- Add more observability features as required.

---

## Summary

**awesomeCache** is a robust, extensible reverse proxy with caching and observability features, suitable for use in front of APIs or web services to improve performance and reliability.

---

If you have any questions or want to extend the project, check the code in each subdirectory or reach out to the maintainers!

