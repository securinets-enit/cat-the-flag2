#!/usr/bin/env bash
set -euo pipefail

BUILD_DIR="${1:-.}"
BIN="$BUILD_DIR/tinyzip"
TD="$BUILD_DIR/test_tmp_cli_roundtrip"

rm -rf "$TD"
mkdir -p "$TD"
pushd "$TD" >/dev/null

# Create input with multiple lines
for i in $(seq 1 100); do
  echo "hello world $i" >> input.txt
done

# Run CLI
"$BIN" compress input.txt
"$BIN" decompress input.txt.gz

# Compare
cmp -s input.txt input.txt.out

popd >/dev/null
rm -rf "$TD"
