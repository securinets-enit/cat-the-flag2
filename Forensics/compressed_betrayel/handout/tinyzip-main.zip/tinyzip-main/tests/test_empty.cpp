#include <cstdio>
#include <string>
#include <vector>
#include "compress.h"
#include "decompress.h"

int main() {
    const std::string inPath  = "empty_input.bin";
    const std::string gzPath  = inPath + ".gz";
    const std::string outPath = inPath + ".out";

    // Create an empty file
    FILE *f = fopen(inPath.c_str(), "wb");
    if (!f) return 10;
    fclose(f);

    // Compress empty file
    int rc = compress_file(inPath.c_str(), gzPath.c_str());
    if (rc != 0) { std::remove(inPath.c_str()); return 20 + (rc & 0xFF); }

    // Decompress back
    rc = decompress_file(gzPath.c_str(), outPath.c_str());
    if (rc != 0) { std::remove(inPath.c_str()); std::remove(gzPath.c_str()); return 30 + (rc & 0xFF); }

    // Ensure output exists and is empty
    FILE *out = fopen(outPath.c_str(), "rb");
    if (!out) { std::remove(inPath.c_str()); std::remove(gzPath.c_str()); return 40; }
    int ch = fgetc(out);
    fclose(out);

    // Cleanup
    std::remove(inPath.c_str());
    std::remove(gzPath.c_str());
    std::remove(outPath.c_str());
#include <cstdio>
#include <string>
#include "compress.h"
#include "decompress.h"

int main() {
    const std::string inPath  = "empty_input.bin";
    const std::string gzPath  = inPath + ".gz";
    const std::string outPath = inPath + ".out";

    // Create an empty file
    FILE *f = fopen(inPath.c_str(), "wb");
    if (!f) return 10;
    fclose(f);

    // Compress empty file
    int rc = compress_file(inPath.c_str(), gzPath.c_str());
    if (rc != 0) { std::remove(inPath.c_str()); return 20 + (rc & 0xFF); }

    // Decompress back
    rc = decompress_file(gzPath.c_str(), outPath.c_str());
    if (rc != 0) { std::remove(inPath.c_str()); std::remove(gzPath.c_str()); return 30 + (rc & 0xFF); }

    // Ensure output exists and is empty
    FILE *out = fopen(outPath.c_str(), "rb");
    if (!out) { std::remove(inPath.c_str()); std::remove(gzPath.c_str()); return 40; }
    int ch = fgetc(out);
    fclose(out);

    // Cleanup
    std::remove(inPath.c_str());
    std::remove(gzPath.c_str());
    std::remove(outPath.c_str());

    // fgetc returns EOF immediately for empty files
    return (ch == EOF) ? 0 : 41;
}
    // fgetc returns EOF immediately for empty files
    return (ch == EOF) ? 0 : 41;
}
