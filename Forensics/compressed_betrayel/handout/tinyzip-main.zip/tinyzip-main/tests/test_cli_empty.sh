#!/usr/bin/env bash
set -euo pipefail

BUILD_DIR="${1:-.}"
BIN="$BUILD_DIR/tinyzip"
TD="$BUILD_DIR/test_tmp_cli_empty"

rm -rf "$TD"
mkdir -p "$TD"
pushd "$TD" >/dev/null

# Create empty input
: > empty.bin

# Run CLI
"$BIN" compress empty.bin
"$BIN" decompress empty.bin.gz

# Verify empty output
if [ -s empty.bin.out ]; then
  echo "Expected empty output"
  exit 1
fi

popd >/dev/null
rm -rf "$TD"
