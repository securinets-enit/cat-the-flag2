#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include "compress.h"
#include "decompress.h"

static bool write_all(const std::string &path, const std::vector<unsigned char> &data) {
    FILE *f = fopen(path.c_str(), "wb");
    if (!f) return false;
    size_t n = fwrite(data.data(), 1, data.size(), f);
    fclose(f);
    return n == data.size();
}

static bool read_all(const std::string &path, std::vector<unsigned char> &out) {
    FILE *f = fopen(path.c_str(), "rb");
    if (!f) return false;
    std::vector<unsigned char> buf;
    unsigned char tmp[4096];
    size_t n;
    while ((n = fread(tmp, 1, sizeof(tmp), f)) > 0) {
        buf.insert(buf.end(), tmp, tmp + n);
    }
    fclose(f);
    out.swap(buf);
    return true;
}

int main() {
    const std::string inPath  = "roundtrip_input.txt";
    const std::string gzPath  = inPath + ".gz";
    const std::string outPath = inPath + ".out";

    // Prepare deterministic content
    std::vector<unsigned char> content;
    const char *msg = "The quick brown fox jumps over the lazy dog.\n"
                      "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ\n";
    for (int i = 0; i < 128; ++i) {
        content.insert(content.end(), msg, msg + std::strlen(msg));
    }

    // Write input
    if (!write_all(inPath, content)) return 10;

    // Compress
    int rc = compress_file(inPath.c_str(), gzPath.c_str());
    if (rc != 0) { std::remove(inPath.c_str()); return 20 + (rc & 0xFF); }
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include "compress.h"
#include "decompress.h"

static bool write_all(const std::string &path, const std::vector<unsigned char> &data) {
    FILE *f = fopen(path.c_str(), "wb");
    if (!f) return false;
    size_t n = fwrite(data.data(), 1, data.size(), f);
    fclose(f);
    return n == data.size();
}

static bool read_all(const std::string &path, std::vector<unsigned char> &out) {
    FILE *f = fopen(path.c_str(), "rb");
    if (!f) return false;
    std::vector<unsigned char> buf;
    unsigned char tmp[4096];
    size_t n;
    while ((n = fread(tmp, 1, sizeof(tmp), f)) > 0) {
        buf.insert(buf.end(), tmp, tmp + n);
    }
    fclose(f);
    out.swap(buf);
    return true;
}

int main() {
    const std::string inPath  = "roundtrip_input.txt";
    const std::string gzPath  = inPath + ".gz";
    const std::string outPath = inPath + ".out";

    // Prepare deterministic content
    std::vector<unsigned char> content;
    const char *msg = "The quick brown fox jumps over the lazy dog.\n"
                      "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ\n";
    for (int i = 0; i < 128; ++i) {
        content.insert(content.end(), msg, msg + std::strlen(msg));
    }

    // Write input
    if (!write_all(inPath, content)) return 10;

    // Compress
    int rc = compress_file(inPath.c_str(), gzPath.c_str());
    if (rc != 0) { std::remove(inPath.c_str()); return 20 + (rc & 0xFF); }

    // Decompress
    rc = decompress_file(gzPath.c_str(), outPath.c_str());
    if (rc != 0) { std::remove(inPath.c_str()); std::remove(gzPath.c_str()); return 30 + (rc & 0xFF); }

    // Read back and compare
    std::vector<unsigned char> roundtrip;
    bool ok = read_all(outPath, roundtrip);
    int ret = 0;
    if (!ok) ret = 40;
    else if (roundtrip.size() != content.size()) ret = 41;
    else if (!std::equal(content.begin(), content.end(), roundtrip.begin())) ret = 42;

    // Cleanup
    std::remove(inPath.c_str());
    std::remove(gzPath.c_str());
    std::remove(outPath.c_str());

    return ret;
}
    // Decompress
    rc = decompress_file(gzPath.c_str(), outPath.c_str());
    if (rc != 0) { std::remove(inPath.c_str()); std::remove(gzPath.c_str()); return 30 + (rc & 0xFF); }

    // Read back and compare
    std::vector<unsigned char> roundtrip;
    bool ok = read_all(outPath, roundtrip);
    int ret = 0;
    if (!ok) ret = 40;
    else if (roundtrip.size() != content.size()) ret = 41;
    else if (!std::equal(content.begin(), content.end(), roundtrip.begin())) ret = 42;

    // Cleanup
    std::remove(inPath.c_str());
    std::remove(gzPath.c_str());
    std::remove(outPath.c_str());

    return ret;
}
