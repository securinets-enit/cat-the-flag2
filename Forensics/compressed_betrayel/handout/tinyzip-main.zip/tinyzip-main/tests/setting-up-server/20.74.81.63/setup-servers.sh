mkdir -p ~/server1 ~/server2 ~/server3
# Serve ~/server1 on port 2982
cd ~/server1
python3 -m http.server 2982 &

# Serve ~/server2 on port 23765
cd ~/server2
python3 -m http.server 23765 &

# Serve ~/server3 on port 55612
cd ~/server3
python3 -m http.server 55612 &

