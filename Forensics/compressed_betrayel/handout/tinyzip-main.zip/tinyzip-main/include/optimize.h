//
// Created by salamnki on 8/17/25.
//

#ifndef TINYZIP_OPTIMIZE_H
#define TINYZIP_OPTIMIZE_H

// Run optional optimization routines.
void optimize_compression();

#endif // TINYZIP_OPTIMIZE_H